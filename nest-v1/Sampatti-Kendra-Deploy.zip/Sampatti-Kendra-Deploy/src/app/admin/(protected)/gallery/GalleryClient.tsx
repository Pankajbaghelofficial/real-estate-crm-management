'use client';

import { useState, useEffect, useRef, useCallback } from 'react';

type GalleryFile = {
    filename: string;
    url: string;
    size: number;
    uploadedAt: string;
};

function formatBytes(bytes: number) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(iso: string) {
    return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function GalleryClient() {
    const [files, setFiles] = useState<GalleryFile[]>([]);
    const [loading, setLoading] = useState(true);
    const [uploading, setUploading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState<string[]>([]);
    const [selected, setSelected] = useState<GalleryFile | null>(null);
    const [copied, setCopied] = useState(false);
    const [dragging, setDragging] = useState(false);
    const [search, setSearch] = useState('');
    const [deleting, setDeleting] = useState<string | null>(null);
    const [confirmTarget, setConfirmTarget] = useState<string | null>(null); // custom confirm modal
    const fileInputRef = useRef<HTMLInputElement>(null);
    const dropRef = useRef<HTMLDivElement>(null);

    const loadFiles = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/upload');
            const data = await res.json();
            setFiles(data.files || []);
        } catch { setFiles([]); }
        finally { setLoading(false); }
    }, []);

    useEffect(() => { loadFiles(); }, [loadFiles]);

    async function uploadFiles(fileList: FileList) {
        setUploading(true);
        const msgs: string[] = [];
        for (const file of Array.from(fileList)) {
            msgs.push(`⏳ Uploading ${file.name}...`);
            setUploadProgress([...msgs]);
            const fd = new FormData();
            fd.append('file', file);
            const res = await fetch('/api/upload', { method: 'POST', body: fd });
            const data = await res.json();
            msgs[msgs.length - 1] = res.ok ? `✅ ${file.name}` : `❌ ${file.name}: ${data.error}`;
            setUploadProgress([...msgs]);
        }
        await loadFiles();
        setTimeout(() => setUploadProgress([]), 3000);
        setUploading(false);
    }

    function showConfirm(filename: string) {
        setConfirmTarget(filename);
    }

    async function execDelete() {
        if (!confirmTarget) return;
        const filename = confirmTarget;
        setConfirmTarget(null);
        setDeleting(filename);
        await fetch('/api/upload', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filename }) });
        if (selected?.filename === filename) setSelected(null);
        await loadFiles();
        setDeleting(null);
    }

    function copyUrl(url: string) {
        navigator.clipboard.writeText(window.location.origin + url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    }

    const filtered = files.filter(f => f.filename.toLowerCase().includes(search.toLowerCase()));

    // Drag events
    const onDragOver = (e: React.DragEvent) => { e.preventDefault(); setDragging(true); };
    const onDragLeave = () => setDragging(false);
    const onDrop = (e: React.DragEvent) => {
        e.preventDefault(); setDragging(false);
        if (e.dataTransfer.files.length > 0) uploadFiles(e.dataTransfer.files);
    };

    const CARD: React.CSSProperties = { background: '#fff', borderRadius: '14px', border: '1px solid #eef0f7' };

    return (
        <div style={{ background: '#f5f6fa', minHeight: '100vh', padding: '28px 32px', fontFamily: "'Inter', sans-serif" }}>

            {/* ── Header ── */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
                <div>
                    <h1 style={{ fontSize: '20px', fontWeight: 700, color: '#1a1a2e', margin: 0 }}>🖼️ Media Gallery</h1>
                    <p style={{ fontSize: '13px', color: '#8b8ca7', margin: '4px 0 0' }}>{files.length} image{files.length !== 1 ? 's' : ''} uploaded</p>
                </div>
                <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    style={{
                        display: 'inline-flex', alignItems: 'center', gap: '6px',
                        padding: '9px 20px', borderRadius: '8px', fontSize: '13px',
                        fontWeight: 700, background: uploading ? '#93c5fd' : '#2563eb',
                        color: '#fff', border: 'none', cursor: uploading ? 'wait' : 'pointer',
                    }}
                >
                    {uploading ? '⏳ Uploading...' : '⬆️ Upload Images'}
                </button>
                <input
                    ref={fileInputRef} type="file" multiple accept="image/*"
                    style={{ display: 'none' }}
                    onChange={e => e.target.files && uploadFiles(e.target.files)}
                />
            </div>

            {/* ── Stats ── */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '20px' }}>
                {[
                    { icon: '🖼️', label: 'Total Images', value: files.length, color: '#2563eb', bg: '#eff6ff' },
                    { icon: '💾', label: 'Total Size', value: formatBytes(files.reduce((a, f) => a + f.size, 0)), color: '#7c3aed', bg: '#f5f3ff' },
                    { icon: '📅', label: 'Last Uploaded', value: files[0] ? formatDate(files[0].uploadedAt).split(',')[0] : '—', color: '#16a34a', bg: '#f0fdf4' },
                ].map(s => (
                    <div key={s.label} style={{ ...CARD, padding: '18px 20px', display: 'flex', alignItems: 'center', gap: '14px' }}>
                        <div style={{ width: '42px', height: '42px', borderRadius: '10px', background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px', flexShrink: 0 }}>{s.icon}</div>
                        <div>
                            <p style={{ margin: 0, fontSize: '20px', fontWeight: 700, color: s.color }} suppressHydrationWarning>{s.value}</p>
                            <p style={{ margin: 0, fontSize: '12px', color: '#8b8ca7' }}>{s.label}</p>
                        </div>
                    </div>
                ))}
            </div>

            {/* ── Upload Progress ── */}
            {uploadProgress.length > 0 && (
                <div style={{ ...CARD, padding: '12px 16px', marginBottom: '16px', borderColor: '#bfdbfe' }}>
                    {uploadProgress.map((m, i) => <p key={i} style={{ margin: '2px 0', fontSize: '13px', color: m.startsWith('✅') ? '#16a34a' : m.startsWith('❌') ? '#dc2626' : '#2563eb' }}>{m}</p>)}
                </div>
            )}

            {/* ── Drag & Drop Zone ── */}
            <div
                ref={dropRef}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
                onClick={() => !uploading && fileInputRef.current?.click()}
                style={{
                    border: `2px dashed ${dragging ? '#2563eb' : '#c7d2fe'}`,
                    borderRadius: '12px', background: dragging ? '#eff6ff' : '#f8f9ff',
                    padding: '28px', textAlign: 'center', cursor: 'pointer',
                    marginBottom: '20px', transition: 'all 0.2s ease',
                }}
            >
                <p style={{ fontSize: '28px', margin: '0 0 6px' }}>📤</p>
                <p style={{ margin: 0, fontWeight: 600, color: '#2563eb', fontSize: '14px' }}>
                    {dragging ? 'Drop images here!' : 'Drag & drop images here, or click to browse'}
                </p>
                <p style={{ margin: '4px 0 0', fontSize: '12px', color: '#8b8ca7' }}>JPEG, PNG, WebP, GIF • Max 5MB each • Multiple files allowed</p>
            </div>

            {/* ── Search ── */}
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '16px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#fff', border: '1px solid #e0e0f0', borderRadius: '8px', padding: '8px 12px', flex: 1 }}>
                    <span style={{ color: '#a0a0b5' }}>🔍</span>
                    <input
                        type="text" placeholder="Search images by filename..."
                        value={search} onChange={e => setSearch(e.target.value)}
                        style={{ border: 'none', outline: 'none', fontSize: '13px', color: '#374151', width: '100%', background: 'transparent' }}
                    />
                </div>
                <p style={{ margin: 0, fontSize: '13px', color: '#8b8ca7', whiteSpace: 'nowrap' }}>{filtered.length} of {files.length}</p>
            </div>

            {/* ── Main Content: Grid + Preview ── */}
            <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 300px' : '1fr', gap: '20px', alignItems: 'start' }}>

                {/* Grid */}
                <div style={{ ...CARD, padding: '16px' }}>
                    {loading ? (
                        <div style={{ textAlign: 'center', padding: '60px', color: '#8b8ca7' }}>
                            <p style={{ fontSize: '28px', margin: '0 0 8px' }}>⏳</p>
                            <p style={{ margin: 0 }}>Loading gallery...</p>
                        </div>
                    ) : filtered.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: '60px', color: '#8b8ca7' }}>
                            <p style={{ fontSize: '36px', margin: '0 0 8px' }}>🖼️</p>
                            <p style={{ margin: 0, fontWeight: 600 }}>{search ? 'No images match your search' : 'No images uploaded yet'}</p>
                            <p style={{ margin: '4px 0 0', fontSize: '12px' }}>Use the upload button or drag & drop above</p>
                        </div>
                    ) : (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '10px' }}>
                            {filtered.map(file => (
                                <div
                                    key={file.filename}
                                    onClick={() => setSelected(selected?.filename === file.filename ? null : file)}
                                    style={{
                                        borderRadius: '10px', overflow: 'hidden', cursor: 'pointer',
                                        border: selected?.filename === file.filename ? '2px solid #2563eb' : '2px solid #eef0f7',
                                        background: '#f8f9ff', position: 'relative', transition: 'border-color 0.15s',
                                    }}
                                >
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img
                                        src={file.url} alt={file.filename}
                                        style={{ width: '100%', height: '110px', objectFit: 'cover', display: 'block' }}
                                    />
                                    <div style={{ padding: '6px 8px' }}>
                                        <p style={{ margin: 0, fontSize: '10px', color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 500 }}>
                                            {file.filename.replace(/^upload_\d+_\w+\./, '...')}
                                        </p>
                                        <p style={{ margin: '1px 0 0', fontSize: '10px', color: '#8b8ca7' }}>{formatBytes(file.size)}</p>
                                    </div>
                                    {/* Hover delete button */}
                                    <button
                                        onClick={e => { e.stopPropagation(); showConfirm(file.filename); }}
                                        disabled={deleting === file.filename}
                                        title="Delete"
                                        style={{
                                            position: 'absolute', top: '5px', right: '5px',
                                            width: '22px', height: '22px', borderRadius: '50%',
                                            background: '#dc2626', color: '#fff', border: 'none',
                                            fontSize: '11px', cursor: 'pointer', display: 'flex',
                                            alignItems: 'center', justifyContent: 'center', fontWeight: 700,
                                        }}
                                    >✕</button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Preview Panel */}
                {selected && (
                    <div style={{ ...CARD, padding: '0', overflow: 'hidden', position: 'sticky', top: '0' }}>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={selected.url} alt={selected.filename} style={{ width: '100%', maxHeight: '220px', objectFit: 'cover', display: 'block' }} />
                        <div style={{ padding: '16px' }}>
                            <p style={{ margin: '0 0 12px', fontWeight: 700, color: '#1a1a2e', fontSize: '13px', wordBreak: 'break-all' }}>{selected.filename}</p>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '14px' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', fontSize: '12px' }}>
                                    <span style={{ color: '#8b8ca7', flexShrink: 0 }}>📦 Size</span>
                                    <span style={{ color: '#374151', textAlign: 'right', wordBreak: 'break-all' }}>{formatBytes(selected.size)}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', fontSize: '12px' }}>
                                    <span style={{ color: '#8b8ca7', flexShrink: 0 }}>📅 Uploaded</span>
                                    <span style={{ color: '#374151', textAlign: 'right', wordBreak: 'break-all' }} suppressHydrationWarning>{formatDate(selected.uploadedAt)}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', fontSize: '12px' }}>
                                    <span style={{ color: '#8b8ca7', flexShrink: 0 }}>🔗 URL</span>
                                    <span style={{ color: '#374151', textAlign: 'right', wordBreak: 'break-all' }}>{selected.url}</span>
                                </div>
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <button
                                    onClick={() => copyUrl(selected.url)}
                                    style={{
                                        width: '100%', padding: '9px', borderRadius: '8px', fontSize: '13px',
                                        fontWeight: 600, background: copied ? '#16a34a' : '#2563eb',
                                        color: '#fff', border: 'none', cursor: 'pointer',
                                    }}
                                >
                                    {copied ? '✅ URL Copied!' : '📋 Copy Image URL'}
                                </button>
                                <a href={selected.url} download target="_blank" rel="noreferrer"
                                    style={{ display: 'block', textAlign: 'center', padding: '8px', borderRadius: '8px', fontSize: '13px', fontWeight: 600, background: '#f5f3ff', color: '#7c3aed', textDecoration: 'none', border: '1px solid #ddd6fe' }}>
                                    ⬇️ Download
                                </a>
                                <button
                                    onClick={() => showConfirm(selected.filename)}
                                    disabled={deleting === selected.filename}
                                    style={{ width: '100%', padding: '8px', borderRadius: '8px', fontSize: '13px', fontWeight: 600, background: '#fff1f2', color: '#dc2626', border: '1px solid #fecaca', cursor: 'pointer' }}
                                >
                                    {deleting === selected.filename ? '🗑 Deleting...' : '🗑 Delete Image'}
                                </button>
                                <button onClick={() => setSelected(null)}
                                    style={{ width: '100%', padding: '8px', borderRadius: '8px', fontSize: '12px', color: '#8b8ca7', background: 'transparent', border: 'none', cursor: 'pointer' }}>
                                    Close Preview
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
            {/* ── Delete Confirm Modal ── */}
            {confirmTarget && (
                <div style={{
                    position: 'fixed', inset: 0, zIndex: 9999,
                    background: 'rgba(0,0,0,0.5)', display: 'flex',
                    alignItems: 'center', justifyContent: 'center',
                }} onClick={() => setConfirmTarget(null)}>
                    <div
                        onClick={e => e.stopPropagation()}
                        style={{
                            background: '#fff', borderRadius: '16px', padding: '28px 32px',
                            width: '360px', boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
                            textAlign: 'center', fontFamily: "'Inter', sans-serif",
                        }}
                    >
                        <div style={{ fontSize: '40px', marginBottom: '12px' }}>🗑️</div>
                        <h3 style={{ margin: '0 0 8px', fontSize: '16px', fontWeight: 700, color: '#1a1a2e' }}>Delete Image?</h3>
                        <p style={{ margin: '0 0 6px', fontSize: '12px', color: '#8b8ca7', wordBreak: 'break-all' }}>{confirmTarget}</p>
                        <p style={{ margin: '0 0 24px', fontSize: '13px', color: '#555570' }}>Yeh action undo nahi hogi.</p>
                        <div style={{ display: 'flex', gap: '10px' }}>
                            <button
                                onClick={() => setConfirmTarget(null)}
                                style={{
                                    flex: 1, padding: '10px', borderRadius: '8px', fontSize: '13px',
                                    fontWeight: 600, background: '#f5f6fa', color: '#374151',
                                    border: '1px solid #e0e0f0', cursor: 'pointer',
                                }}
                            >Cancel</button>
                            <button
                                onClick={execDelete}
                                style={{
                                    flex: 1, padding: '10px', borderRadius: '8px', fontSize: '13px',
                                    fontWeight: 700, background: '#dc2626', color: '#fff',
                                    border: 'none', cursor: 'pointer',
                                }}
                            >🗑 Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
